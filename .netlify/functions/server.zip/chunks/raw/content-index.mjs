// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/blog/how-to-buy-steam\":[\"content:blog:how-to-buy-steam.md\"],\"/blog/telegram-stars-guide\":[\"content:blog:telegram-stars-guide.md\"],\"/blog/top-games-october\":[\"content:blog:top-games-october.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
