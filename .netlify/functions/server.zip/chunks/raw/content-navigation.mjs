// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"Blog\",\"_path\":\"/blog\",\"children\":[{\"title\":\"Как безопасно пополнить Steam в 2025 году\",\"_path\":\"/blog/how-to-buy-steam\"},{\"title\":\"Что такое Telegram Stars и зачем они нужны\",\"_path\":\"/blog/telegram-stars-guide\"},{\"title\":\"Топ-10 игр для пополнения в октябре 2025\",\"_path\":\"/blog/top-games-october\"}]}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
